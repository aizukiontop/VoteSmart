// assets/js/realtime.js
//
//     Purpose: Provides real-time utilities for both timestamps and live updating sections (like leaderboards)
//     Includes:
//    1. Clock/time/date helpers
//    2. Auto time field fillers
//    3. Real-time leaderboard refresher
//

//Start a real-time clock in a specific element
function startDateTimeClock(elementId, locale = 'en-US', timeZone = 'Asia/Manila') {
  const target = document.getElementById(elementId);
  if (!target) return;

  const update = () => {
    const now = new Date();
    const options = {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone,
    };
    target.textContent = now.toLocaleString(locale, options);
  };

  update();
  setInterval(update, 1000);
}

//ISO string for precise DB logging
function getCurrentTimestampISO() {
  return new Date().toISOString();
}

//Returns 'YYYY-MM-DD'
function getCurrentDateString() {
  return new Date().toISOString().slice(0, 10);
}

//Returns 'YYYY-MM-DDTHH:MM' for datetime-local inputs
function getDateTimeLocal() {
  return new Date().toISOString().slice(0, 16);
}

//Fill datetime-local input
function fillDateTimeLocal(inputId) {
  const input = document.getElementById(inputId);
  if (input) input.value = getDateTimeLocal();
}

//Fill date-only input
function fillDateOnly(inputId) {
  const input = document.getElementById(inputId);
  if (input) input.value = getCurrentDateString();
}

//Auto-fill multiple named inputs (good for PHP-style forms)
function autoFillTimeFields() {
  const entryInput = document.querySelector('input[name="entry_time"]');
  const dateInput = document.querySelector('input[name="date"]');
  if (entryInput) entryInput.value = getDateTimeLocal();
  if (dateInput) dateInput.value = getCurrentDateString();
}

//Optionally refresh inputs every X seconds
function autoUpdateTimeInputs(intervalMs = 10000) {
  autoFillTimeFields();
  setInterval(autoFillTimeFields, intervalMs);
}

//NEW: Real-time leaderboard auto-refresh
//Call this on dashboard pages to update live vote results.
function startLiveLeaderboardRefresh(
  targetSelector = "#leaderboard-content",
  sourceUrl = "dashboard.php?ajax=1",
  intervalMs = 5000
) {
  const container = document.querySelector(targetSelector);
  if (!container) return;

  const refreshLeaderboard = () => {
    fetch(sourceUrl)
      .then((res) => res.text())
      .then((html) => {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, "text/html");
        const updated = doc.querySelector(targetSelector);
        if (updated) container.innerHTML = updated.innerHTML;
      })
      .catch((err) => console.error("Leaderboard refresh failed:", err));
  };

  refreshLeaderboard();
  setInterval(refreshLeaderboard, intervalMs);
}

//Optional: You can trigger both the clock and leaderboard on DOM load
document.addEventListener("DOMContentLoaded", () => {
  //Example usage:
  //startDateTimeClock("clock");
  //startLiveLeaderboardRefresh();
});
