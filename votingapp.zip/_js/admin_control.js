// _js/admin_control.js
document.addEventListener("DOMContentLoaded", () => {
  const electionItems = document.querySelectorAll(".election-item");
  const statusSection = document.querySelector(".status-section");
  const statusLabel = document.querySelector(".status-value");
  const statusDropdown = document.querySelector("select[name='status']");
  const updateBtn = document.querySelector("button[name='update_status']");
  const messageBox = document.querySelector(".msg");
  const electionTypeSelect = document.getElementById("election_type");
  const timedFields = document.getElementById("timed_fields");

  let activeElection = null;
  let electionTimer = null;

  // Toggle fields for timed/open elections
  if (electionTypeSelect) {
    electionTypeSelect.addEventListener("change", () => {
      if (timedFields) timedFields.style.display =
        electionTypeSelect.value === "timed" ? "block" : "none";
    });
  }

  // Hide status section until an election is selected
  if (statusSection) statusSection.style.display = "none";

  // When clicking an existing election
  electionItems.forEach(item => {
    item.addEventListener("click", async () => {
      activeElection = item.dataset.id;

      // Highlight selected
      electionItems.forEach(i => i.classList.remove("active"));
      item.classList.add("active");

      // Show status section
      if (statusSection) statusSection.style.display = "block";
      if (messageBox)
        messageBox.innerHTML = `✅ Managing election: <strong>${item.dataset.name}</strong>`;

      // Fetch election details
      try {
        const res = await fetch(`includes/get_election.php?id=${activeElection}`);
        const data = await res.json();

        if (data.success) {
          updateStatusUI(data.status);
          setupAutoStatus(data);
        } else {
          messageBox.textContent = "⚠️ Failed to fetch election details.";
        }
      } catch (err) {
        console.error(err);
        if (messageBox) messageBox.textContent = "⚠️ Error loading election details.";
      }
    });
  });

  // Manual update (for open elections)
  if (updateBtn) {
    updateBtn.addEventListener("click", async e => {
      e.preventDefault();
      if (!activeElection) return alert("Select an election first.");
      const newStatus = statusDropdown.value;

      try {
        const res = await fetch("includes/update_status.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ election_id: activeElection, status: newStatus }),
        });
        const data = await res.json();

        if (data.success) {
          updateStatusUI(newStatus);
          messageBox.textContent = `✅ Status updated to '${newStatus}'.`;
        } else {
          messageBox.textContent = "⚠️ Failed to update status.";
        }
      } catch (err) {
        console.error(err);
        messageBox.textContent = "⚠️ Network error updating status.";
      }
    });
  }

  // Automatically handle timed elections
  function setupAutoStatus(election) {
    clearInterval(electionTimer);
    if (election.type !== "timed") return;

    const startTime = new Date(election.start_date).getTime();
    const endTime = new Date(election.end_date).getTime();

    electionTimer = setInterval(async () => {
      const now = Date.now();
      let newStatus = election.status;

      if (now < startTime) newStatus = "upcoming";
      else if (now >= startTime && now <= endTime) newStatus = "ongoing";
      else if (now > endTime) newStatus = "closed";

      if (newStatus !== election.status) {
        election.status = newStatus;
        updateStatusUI(newStatus);

        // Update DB silently
        await fetch("includes/update_status.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ election_id: election.election_id, status: newStatus }),
        });

        if (messageBox)
          messageBox.textContent = `⏱️ Election automatically set to '${newStatus}'.`;
      }
    }, 10000);
  }

  function updateStatusUI(status) {
    if (statusLabel)
      statusLabel.textContent = status.charAt(0).toUpperCase() + status.slice(1);
    if (statusDropdown) statusDropdown.value = status;
  }
});
