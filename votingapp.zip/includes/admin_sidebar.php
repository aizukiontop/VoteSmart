<?php
require_once __DIR__ . '/../_sql/db.php';

// Fetch system settings
$stmt = $pdo->query("SELECT * FROM election_settings LIMIT 1");
$setting = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$setting) {
    $pdo->exec("INSERT INTO election_settings (status) VALUES ('upcoming')");
    $stmt = $pdo->query("SELECT * FROM election_settings LIMIT 1");
    $setting = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Fetch all elections
$elections = $pdo->query("SELECT * FROM elections ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

// Handle actions
$message = '';
$selected_election = null;

if (isset($_GET['election_id'])) {
    $id = intval($_GET['election_id']);
    $stmt = $pdo->prepare("SELECT * FROM elections WHERE election_id = ?");
    $stmt->execute([$id]);
    $selected_election = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Add new election (only one ongoing allowed)
    if (isset($_POST['add_election'])) {
        $title = trim($_POST['election_name']);
        $desc = trim($_POST['description']);
        $type = $_POST['election_type'] ?? 'open';
        $start = $_POST['start_date'] ?? null;
        $end = $_POST['end_date'] ?? null;

        if ($title) {
            if ($type === 'timed' && (!$start || !$end)) {
                $message = "Please provide start and end dates for a timed election.";
            } else {
                // Prevent multiple ongoing elections
                $check = $pdo->query("SELECT COUNT(*) FROM elections WHERE status = 'ongoing'")->fetchColumn();
                if ($check > 0) {
                    $message = "⚠️ Cannot add another ongoing election. Close the current one first.";
                } else {
                    $stmt = $pdo->prepare("
                        INSERT INTO elections (election_name, description, start_date, end_date, election_type, status)
                        VALUES (?, ?, ?, ?, ?, 'upcoming')
                    ");
                    $stmt->execute([$title, $desc, $start, $end, $type]);
                    $new_id = $pdo->lastInsertId();
                    $message = "New $type election '$title' added.";
                    header("Location: ?election_id=$new_id");
                    exit;
                }
            }
        } else {
            $message = "Please enter an election title.";
        }
    }

    // Update election status — only one can be 'ongoing'
    if (isset($_POST['update_status']) && isset($_POST['election_id'])) {
        $status = $_POST['status'] ?? 'upcoming';
        $election_id = intval($_POST['election_id']);

        if ($status === 'ongoing') {
            // Automatically close all other elections
            $pdo->prepare("UPDATE elections SET status = 'closed' WHERE election_id != ?")->execute([$election_id]);
        }

        $update = $pdo->prepare("UPDATE elections SET status = ? WHERE election_id = ?");
        $update->execute([$status, $election_id]);
        $message = "Election status updated to '$status'.";

        header("Location: ?election_id=$election_id");
        exit;
    }
}
?>

<section class="sidebar left">
    <h2>🗳️ Election Control</h2>
    <p>Welcome, <strong><?= htmlspecialchars($admin_name) ?></strong></p>
    <?php if ($message): ?><div class="msg"><?= htmlspecialchars($message) ?></div><?php endif; ?>

    <!-- Existing Elections -->
    <div class="election-list">
        <h3>Existing Elections</h3>
        <?php if ($elections): ?>
            <ul>
                <?php foreach ($elections as $e): ?>
                    <li>
                        <a href="?election_id=<?= $e['election_id'] ?>"
                           class="election-link <?= ($selected_election && $selected_election['election_id'] == $e['election_id']) ? 'active' : '' ?>">
                            <strong><?= htmlspecialchars($e['election_name']) ?></strong>
                            <span class="badge <?= htmlspecialchars($e['status']) ?>">
                                <?= ucfirst($e['status']) ?> (<?= htmlspecialchars($e['election_type']) ?>)
                            </span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No elections yet.</p>
        <?php endif; ?>
    </div>

    <!-- Add New Election -->
    <div class="election-section">
        <h3>Add New Election</h3>
        <form method="POST" id="addElectionForm">
            <input type="text" name="election_name" placeholder="Election Title" required>
            <textarea name="description" placeholder="Description (optional)"></textarea>

            <label>Election Type:</label>
            <select name="election_type" id="election_type" required>
                <option value="open">Open (No time limit)</option>
                <option value="timed">Timed (Start & End required)</option>
            </select>

            <div id="timedFields" style="display:none;">
                <label>Start Date:</label>
                <input type="datetime-local" name="start_date">
                <label>End Date:</label>
                <input type="datetime-local" name="end_date">
            </div>

            <button type="submit" name="add_election">Add Election</button>
        </form>
    </div>

    <!-- Election Status (only visible when one is selected) -->
    <?php if ($selected_election): ?>
        <div class="status-section">
            <h3>Election: <?= htmlspecialchars($selected_election['election_name']) ?></h3>
            <p>Type: <strong><?= htmlspecialchars(ucfirst($selected_election['election_type'])) ?></strong></p>
            <p><?= htmlspecialchars($selected_election['description'] ?: 'No description provided.') ?></p>

            <?php if ($selected_election['election_type'] === 'timed'): ?>
                <p>Start: <?= htmlspecialchars($selected_election['start_date']) ?></p>
                <p>End: <?= htmlspecialchars($selected_election['end_date']) ?></p>
            <?php endif; ?>

            <p>Current Status: <span class="status <?= htmlspecialchars($selected_election['status']) ?>">
                <?= ucfirst($selected_election['status']) ?></span></p>

            <form method="POST">
                <input type="hidden" name="election_id" value="<?= $selected_election['election_id'] ?>">
                <select name="status" required>
                    <option value="upcoming" <?= $selected_election['status'] === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
                    <option value="ongoing" <?= $selected_election['status'] === 'ongoing' ? 'selected' : '' ?>>Ongoing</option>
                    <option value="closed" <?= $selected_election['status'] === 'closed' ? 'selected' : '' ?>>Closed</option>
                </select>
                <button type="submit" name="update_status">Update Status</button>
            </form>
        </div>
    <?php endif; ?>
</section>

<script src="../_js/admin_control.js"></script>
