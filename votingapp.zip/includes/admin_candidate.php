<?php
require_once __DIR__ . '/../_sql/db.php';

// --- Helper: Standard Positions ---
$defaultPositions = [
    'President',
    'Vice President',
    'Secretary',
    'Treasurer',
    'Auditor',
    'Public Relations Officer',
    '1st Year Representative',
    '2nd Year Representative',
    '3rd Year Representative',
    '4th Year Representative'
];

// --- Get all elections ---
$elections = $pdo->query("
    SELECT election_id, election_name, status, election_type, start_date, end_date
    FROM elections
    ORDER BY created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// --- Find the active (upcoming or ongoing) election ---
$activeElection = $pdo->query("
    SELECT election_id, election_name, status 
    FROM elections 
    WHERE status IN ('upcoming', 'ongoing')
    ORDER BY FIELD(status, 'ongoing', 'upcoming') 
    LIMIT 1
")->fetch(PDO::FETCH_ASSOC);

$currentElectionId = $activeElection['election_id'] ?? null;
$currentElectionName = $activeElection['election_name'] ?? '—';
$currentElectionStatus = $activeElection['status'] ?? null;

$message = '';

// --- Ensure default positions exist for active election ---
if ($currentElectionId) {
    foreach ($defaultPositions as $index => $posName) {
        $check = $pdo->prepare("SELECT position_id FROM positions WHERE election_id = ? AND position_name = ?");
        $check->execute([$currentElectionId, $posName]);
        if (!$check->fetch()) {
            $insert = $pdo->prepare("INSERT INTO positions (election_id, position_name, sort_order) VALUES (?, ?, ?)");
            $insert->execute([$currentElectionId, $posName, $index + 1]);
        }
    }
}

// --- Reload Positions ---
$positions = [];
if ($currentElectionId) {
    $posStmt = $pdo->prepare("SELECT * FROM positions WHERE election_id = ? ORDER BY sort_order");
    $posStmt->execute([$currentElectionId]);
    $positions = $posStmt->fetchAll(PDO::FETCH_ASSOC);
}

// --- Remove Candidate ---
if (isset($_POST['remove_candidate']) && isset($_POST['candidate_id'])) {
    $candidateId = (int)$_POST['candidate_id'];
    $stmt = $pdo->prepare("DELETE FROM candidates WHERE candidate_id = ?");
    $stmt->execute([$candidateId]);
    $message = "Candidate removed successfully.";
}

// --- Add Candidate ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_candidate'])) {
    $name = trim($_POST['candidate_name']);
    $new_partylist = trim($_POST['new_partylist']);
    $partylist_id = $_POST['partylist_id'] ?: null;
    $new_position = trim($_POST['new_position']);
    $position_id = $_POST['position_id'] ?: null;
    $year_level = $_POST['year_level'] ?? null;
    $platform = trim($_POST['platform'] ?? '');
    $experience = trim($_POST['experience'] ?? '');

    if (!$currentElectionId) {
        $message = "No active or upcoming election available.";
    } else {
        // Partylist check
        if ($new_partylist) {
            $check = $pdo->prepare("SELECT partylist_id FROM partylists WHERE partylist_name = ?");
            $check->execute([$new_partylist]);
            $existing = $check->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                $partylist_id = $existing['partylist_id'];
            } else {
                $stmt = $pdo->prepare("INSERT INTO partylists (partylist_name) VALUES (?)");
                $stmt->execute([$new_partylist]);
                $partylist_id = $pdo->lastInsertId();
            }
        }

        // Position check
        if ($new_position) {
            $check = $pdo->prepare("SELECT position_id FROM positions WHERE election_id = ? AND position_name = ?");
            $check->execute([$currentElectionId, $new_position]);
            $existing = $check->fetch(PDO::FETCH_ASSOC);
            if ($existing) {
                $position_id = $existing['position_id'];
            } else {
                $stmt = $pdo->prepare("INSERT INTO positions (election_id, position_name) VALUES (?, ?)");
                $stmt->execute([$currentElectionId, $new_position]);
                $position_id = $pdo->lastInsertId();
            }
        }

        if ($name && $position_id) {
            $stmt = $pdo->prepare("
                INSERT INTO candidates 
                (candidate_name, position_id, partylist_id, year_level, platform, experience, election_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $position_id, $partylist_id, $year_level, $platform, $experience, $currentElectionId]);
            $message = "Candidate '$name' added successfully!";
        } else {
            $message = "Missing candidate details.";
        }
    }
}

// --- Reload Candidates grouped by Position ---
$candidatesByPosition = [];
if ($currentElectionId) {
    $stmt = $pdo->prepare("
        SELECT c.*, p.position_name, pl.partylist_name
        FROM candidates c
        JOIN positions p ON c.position_id = p.position_id
        LEFT JOIN partylists pl ON c.partylist_id = pl.partylist_id
        WHERE c.election_id = ?
        ORDER BY p.sort_order, c.candidate_name
    ");
    $stmt->execute([$currentElectionId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $c) {
        $candidatesByPosition[$c['position_name']][] = $c;
    }
}
?>

<link rel="stylesheet" href="_css/admin_candidates.css">

<section class="admin-candidate">
    <h2>Candidate Management</h2>
    <?php if ($message): ?><div class="msg"><?= htmlspecialchars($message) ?></div><?php endif; ?>

    <?php if ($currentElectionId): ?>
        <p>Active Election: <strong><?= htmlspecialchars($currentElectionName) ?></strong> (<?= ucfirst($currentElectionStatus) ?>)</p>

        <form method="POST" class="candidate-form">
            <input type="text" name="candidate_name" placeholder="Candidate Name" required>

            <label>Year Level</label>
            <select name="year_level" required>
                <option value="">-- Select Year Level --</option>
                <option>1st Year</option>
                <option>2nd Year</option>
                <option>3rd Year</option>
                <option>4th Year</option>
            </select>

            <label>Platform</label>
            <textarea name="platform" placeholder="Candidate’s goals or advocacy..." rows="3"></textarea>

            <label>Experience</label>
            <input type="text" name="experience" placeholder="Separate with commas (e.g. Former VP, Coordinator)" />

            <label>Partylist</label>
            <div class="dual-input">
                <select name="partylist_id">
                    <option value="">-- Select Existing --</option>
                    <?php foreach ($partylists as $p): ?>
                        <option value="<?= $p['partylist_id'] ?>"><?= htmlspecialchars($p['partylist_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <span>OR</span>
                <input type="text" name="new_partylist" placeholder="New Partylist Name">
            </div>

            <label>Position</label>
            <div class="dual-input">
                <select name="position_id">
                    <option value="">-- Select Existing --</option>
                    <?php foreach ($positions as $pos): ?>
                        <option value="<?= $pos['position_id'] ?>"><?= htmlspecialchars($pos['position_name']) ?></option>
                    <?php endforeach; ?>
                </select>
                <span>OR</span>
                <input type="text" name="new_position" placeholder="New Position">
            </div>

            <button type="submit" name="add_candidate" class="btn-add">Add Candidate</button>
        </form>

        <div class="candidate-list">
            <h4>Existing Candidates by Position</h4>
            <?php foreach ($positions as $pos): ?>
                <div class="position-block">
                    <h3><?= htmlspecialchars($pos['position_name']) ?></h3>
                    <?php if (!empty($candidatesByPosition[$pos['position_name']])): ?>
                        <?php foreach ($candidatesByPosition[$pos['position_name']] as $c): ?>
                            <div class="candidate-card">
                                <div class="candidate-header">
                                    <div class="avatar"><?= strtoupper(substr($c['candidate_name'], 0, 1)) ?></div>
                                    <div class="info">
                                        <h3><?= htmlspecialchars($c['candidate_name']) ?> <span class="verified">✔</span></h3>
                                        <p class="partylist"><?= htmlspecialchars($c['partylist_name'] ?? 'Independent') ?></p>
                                        <p class="year">🎓 <?= htmlspecialchars($c['year_level'] ?? '—') ?></p>
                                    </div>
                                </div>

                                <div class="section">
                                    <strong>Platform</strong>
                                    <p><?= htmlspecialchars($c['platform'] ?? '—') ?></p>
                                </div>

                                <div class="section">
                                    <strong>Experience</strong>
                                    <div class="tags">
                                        <?php foreach (array_filter(explode(',', $c['experience'] ?? '')) as $exp): ?>
                                            <span class="tag"><?= htmlspecialchars(trim($exp)) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <form method="POST" onsubmit="return confirm('Remove this candidate?');">
                                    <input type="hidden" name="candidate_id" value="<?= $c['candidate_id'] ?>">
                                    <button type="submit" name="remove_candidate" class="remove-btn">Remove</button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="no-candidates">No candidates for this position yet.</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="inactive-message">
            <p>No <strong>upcoming</strong> or <strong>ongoing</strong> election found. Add or activate one to enable candidate registration.</p>
        </div>
    <?php endif; ?>
</section>
