<?php
require_once __DIR__ . '/../_sql/db.php';
header('Content-Type: application/json');

$id = $_GET['id'] ?? null;
if (!$id || !is_numeric($id)) {
    echo json_encode(['success' => false, 'message' => 'Missing or invalid election ID']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT 
            election_id, 
            election_name, 
            description,
            status, 
            start_date, 
            end_date,
            CASE 
                WHEN start_date IS NULL OR end_date IS NULL THEN 'open'
                ELSE 'timed'
            END AS type
        FROM elections 
        WHERE election_id = ?
    ");
    $stmt->execute([$id]);
    $election = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($election) {
        echo json_encode(['success' => true, 'data' => $election]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Election not found']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
