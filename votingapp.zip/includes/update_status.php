<?php
require_once __DIR__ . '/../_sql/db.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['election_id'] ?? null;
$status = $data['status'] ?? null;

if (!$id || !$status) {
    echo json_encode(['success' => false, 'message' => 'Missing parameters']);
    exit;
}

try {
    $stmt = $pdo->prepare("UPDATE elections SET status = ?, updated_at = NOW() WHERE election_id = ?");
    $stmt->execute([$status, $id]);

    echo json_encode(['success' => true, 'message' => "Status updated to '$status'"]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
}
?>
