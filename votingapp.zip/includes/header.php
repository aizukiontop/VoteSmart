<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../_sql/db.php';

$user_name = $_SESSION['full_name'] ?? 'Guest';
$role = $_SESSION['role'] ?? 'student';
$user_id = $_SESSION['user_id'] ?? null;

// Default states
$election_active = false;
$already_voted = false;

// 1. Check if there’s an ongoing election in `elections` table
$election_query = $pdo->query("SELECT election_id FROM elections WHERE status = 'ongoing' LIMIT 1");
$active_election = $election_query->fetch(PDO::FETCH_ASSOC);
$election_active = !empty($active_election);

// 2. Check if user already voted in that election
if ($user_id && $active_election) {
    $vote_query = $pdo->prepare("SELECT COUNT(*) FROM votes WHERE user_id = ? AND election_id = ?");
    $vote_query->execute([$user_id, $active_election['election_id']]);
    $already_voted = $vote_query->fetchColumn() > 0;
}
?>


<header class="main-header">
    <div class="header-container">
        <div class="header-left">
            <h2 class="logo">VoteSmart</h2>
            <nav class="nav-links">
                <a href="home.php" class="nav-item">Home</a>

                <?php if (!$election_active): ?>
                    <!-- Election not yet started -->
                    <a href="#" class="nav-item disabled" title="Voting not yet available">Not Yet Open</a>

                <?php elseif ($already_voted): ?>
                    <!-- User already voted -->
                    <a href="already_voted.php" class="nav-item">Already Voted</a>

                <?php else: ?>
                    <!-- Election active & not yet voted -->
                    <a href="vote.php" class="nav-item active">Vote</a>
                <?php endif; ?>

                <a href="results.php" class="nav-item">Results</a>
            </nav>
        </div>

        <div class="header-right">
            <span class="welcome-text">Welcome,</span>
            <span class="username"><?= htmlspecialchars($user_name) ?></span>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
    </div>
</header>
                    