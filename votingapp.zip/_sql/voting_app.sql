-- --------------------------------------------------
-- 1. Create Database
-- --------------------------------------------------
DROP DATABASE IF EXISTS voting_app;
CREATE DATABASE voting_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE voting_app;

-- --------------------------------------------------
-- 2. Users Table (Students + Admins)
-- --------------------------------------------------
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    student_number VARCHAR(30) UNIQUE NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(100) NOT NULL,
    role ENUM('student','admin') DEFAULT 'student',
    status ENUM('active','inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Index for faster login queries
CREATE INDEX idx_email ON users(email);


CREATE TABLE election_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    status ENUM('upcoming', 'active', 'closed') NOT NULL DEFAULT 'upcoming',
    start_date DATETIME NULL,
    end_date DATETIME NULL
);

-- insert default row (so your PHP query always finds one)
INSERT INTO election_settings (status) VALUES ('upcoming');

-- --------------------------------------------------
-- 3. Elections Table
-- --------------------------------------------------
CREATE TABLE elections (
    election_id INT AUTO_INCREMENT PRIMARY KEY,
    election_name VARCHAR(150) NOT NULL,
    description TEXT,
    start_date DATETIME NULL,
    end_date DATETIME NULL,
    election_type ENUM('open', 'timed') DEFAULT 'open',
    status ENUM('upcoming','ongoing','closed') DEFAULT 'upcoming',
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_election_dates CHECK (
        election_type = 'open' OR (start_date IS NOT NULL AND end_date IS NOT NULL AND end_date > start_date)
    ),
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);


CREATE INDEX idx_status ON elections(status);

-- --------------------------------------------------
-- 4. Partylists Table
-- --------------------------------------------------
CREATE TABLE partylists (
    partylist_id INT AUTO_INCREMENT PRIMARY KEY,
    partylist_name VARCHAR(150) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------
-- 5. Positions Table
-- --------------------------------------------------
CREATE TABLE positions (
    position_id INT AUTO_INCREMENT PRIMARY KEY,
    election_id INT NOT NULL,
    position_name VARCHAR(150) NOT NULL,
    max_votes INT DEFAULT 1,
    sort_order INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE CASCADE
);

CREATE INDEX idx_position_election ON positions(election_id);

-- --------------------------------------------------
-- 6. Candidates Table
-- --------------------------------------------------
CREATE TABLE candidates (
    candidate_id INT AUTO_INCREMENT PRIMARY KEY,
    position_id INT NOT NULL,
    partylist_id INT NULL,
    election_id INT NOT NULL,
    candidate_name VARCHAR(150) NOT NULL,
    year_level VARCHAR(20) NULL,
    platform TEXT NULL,
    experience TEXT NULL,
    image_url VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (position_id) REFERENCES positions(position_id) ON DELETE CASCADE,
    FOREIGN KEY (partylist_id) REFERENCES partylists(partylist_id) ON DELETE SET NULL,
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE CASCADE
);

CREATE INDEX idx_candidate_position ON candidates(position_id);

-- --------------------------------------------------
-- 7. Votes Table
-- --------------------------------------------------
CREATE TABLE votes (
    vote_id INT AUTO_INCREMENT PRIMARY KEY,
    election_id INT NOT NULL,
    user_id INT NOT NULL,
    position_id INT NOT NULL,
    candidate_id INT NOT NULL,
    voted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (election_id) REFERENCES elections(election_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (position_id) REFERENCES positions(position_id) ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    UNIQUE (election_id, user_id, position_id)
);

CREATE INDEX idx_vote_check ON votes(election_id, user_id, position_id);
CREATE INDEX idx_votes_cand ON votes(candidate_id);
CREATE INDEX idx_votes_election_pos ON votes(election_id, position_id, candidate_id);

-- --------------------------------------------------
-- 8. Live Results View
-- --------------------------------------------------
CREATE OR REPLACE VIEW live_results AS
SELECT 
    e.election_id,
    e.election_name,
    p.position_id,
    p.position_name,
    p.sort_order,
    c.candidate_id,
    c.candidate_name,
    COALESCE(pl.partylist_name, 'Independent') AS partylist_name,
    COUNT(v.vote_id) AS total_votes
FROM positions p
JOIN elections e ON e.election_id = p.election_id
LEFT JOIN candidates c ON c.position_id = p.position_id
LEFT JOIN partylists pl ON pl.partylist_id = c.partylist_id
LEFT JOIN votes v ON v.candidate_id = c.candidate_id
GROUP BY p.position_id, c.candidate_id
ORDER BY p.sort_order ASC, total_votes DESC;

-- --------------------------------------------------
-- 9. Default Admin Account
-- --------------------------------------------------
INSERT INTO users (full_name, student_number, email, password, role)
VALUES 
('System Admin', '0000', 'admin@hau.edu.ph', 'admin123', 'admin'),
('Test Student 1', '20974408', 'lcbasilio2@student.hau.edu.ph', 'Testpass1', 'student'),
('Test Student 2', '20866814', 'madingal@student.hau.edu.ph', 'Testpass2', 'student'),
('Test Student 3', '20937734', 'dgarcia@student.hau.edu.ph', 'Testpass3', 'student'),
('Test Student 4', '20962462', 'jrsicat@student.hau.edu.ph', 'Testpass4', 'student');
